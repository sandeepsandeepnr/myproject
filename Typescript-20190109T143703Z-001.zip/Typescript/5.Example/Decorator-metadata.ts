function metadataParameterDec(target: any,  
    methodName : string,  
    parameterIndex: number) { 
   
    } 

  class ClassWithMetaData { 
    print(  
      @metadataParameterDec  
      id: number,  
      name: string) : number { 
      return 1000; 
      } 
  } 