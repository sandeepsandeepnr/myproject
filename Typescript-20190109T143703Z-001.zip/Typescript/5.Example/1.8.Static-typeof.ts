function propertyDec(target: any, propertyKey: string) {
  if (typeof (target) === 'function') {
    console.log(`static members class name : ${target.name}`);
  } else {
    console.log(`No static members class nameclass name : ${target.constructor.name}`);
  }

  console.log(`propertyKey : ${propertyKey}`);
}


class ClassWithPropertyDec {
  @propertyDec
  name: string;
}

class StaticClassWithPropertyDec {
  @propertyDec
  static name: string;
}
