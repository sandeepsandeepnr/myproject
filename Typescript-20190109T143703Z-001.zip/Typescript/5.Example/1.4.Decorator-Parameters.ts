function classConstructorDec(constructor: Function) { 
      console.log(`constructor : ${constructor}`); 
    } 
 
    @classConstructorDec 
    class ClassWithConstructor { 
     
    } 