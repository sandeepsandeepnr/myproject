var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
function auditLogDec(target, methodName, descriptor) {
    var originalFunction = target[methodName];
    var auditFunction = function () {
        console.log("auditLogDec : overide of "
            + (" " + methodName + " called "));
        originalFunction.apply(this, arguments);
    };
    target[methodName] = auditFunction;
}
var ClassWithAuditDec = /** @class */ (function () {
    function ClassWithAuditDec() {
    }
    ClassWithAuditDec.prototype.print = function (output) {
        console.log("ClassWithMethodDec.print"
            + ("(" + output + ") called."));
    };
    __decorate([
        auditLogDec
    ], ClassWithAuditDec.prototype, "print");
    return ClassWithAuditDec;
}());
var auditClass = new ClassWithAuditDec();
auditClass.print("test");
