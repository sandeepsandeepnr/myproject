function simpleDecorator(constructor : Function) { 
    console.log('simpleDecorator called.'); 
  } 

  @simpleDecorator 
  class ClassWithSimpleDecorator { 
   //Decorators are only invoked as the class is being defined
  } 

  let instance1 = new ClassWithSimpleDecorator();
  console.log(`Object 1 : ${instance1}`)