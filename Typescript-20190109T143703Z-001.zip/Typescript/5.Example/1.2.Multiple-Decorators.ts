function simpleDecorator(constructor : Function) { 
    console.log('simpleDecorator called.'); 
  } 

function secondDecorator(constructor : Function) { 
      console.log('secondDecorator called.') 
    } 
 
    @simpleDecorator 
    @secondDecorator 
    class ClassWithMultipleDecorators { 
  
    }  


    //Decorators are evaluated in the order 
    //they appear in the code, but are then called in reverse order.