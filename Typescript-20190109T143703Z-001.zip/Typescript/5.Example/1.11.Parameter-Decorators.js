function parameterDec(target, methodName, parameterIndex) {
    console.log("target: " + target);
    console.log("methodName : " + methodName);
    console.log("parameterIndex : " + parameterIndex);
}
var ClassWithParamDec = /** @class */ (function () {
    function ClassWithParamDec() {
    }
    ClassWithParamDec.prototype.print = function (value) {
    };
    return ClassWithParamDec;
}());
var obj1 = new ClassWithParamDec();
