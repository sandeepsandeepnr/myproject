var item1 :any  = { id: 1, name: "item 1" }; 
    item1 = { id: 2 }; 
   