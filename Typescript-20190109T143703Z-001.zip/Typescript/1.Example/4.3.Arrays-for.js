var arrayOfStrings = ["first", "second", "third"];
for (var _i = 0, arrayOfStrings_1 = arrayOfStrings; _i < arrayOfStrings_1.length; _i++) {
    var arrayItem = arrayOfStrings_1[_i];
    console.log("arrayItem = " + arrayItem + " ");
}
