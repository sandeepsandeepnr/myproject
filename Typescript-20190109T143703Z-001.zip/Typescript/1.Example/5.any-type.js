var item1 = { id: 1, name: "item 1" };
item1 = { id: 2 };
