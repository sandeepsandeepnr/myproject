var complexType = { name: "myName", id: 1 };
complexType = { name: "anotherName" };
