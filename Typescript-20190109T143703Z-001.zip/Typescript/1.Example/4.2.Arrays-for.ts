var arrayOfStrings : string[] = ["first", "second", "third"]; 
 
for( var itemKey in arrayOfStrings) { 
var itemValue = arrayOfStrings[itemKey]; 
console.log(`$arrayOfStrings[${itemKey}] = ${itemValue}`); 
  } 