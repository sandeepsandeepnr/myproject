function greetUser(username) {
    // Reverse the username
    var reversed = username.split('').reverse().join('');
    return `Hi, ${reversed}`
}
console.log('Greet a correct user: ', greetUser("sathish"))
//console.log('Greet a correct user: ', greetUser(true))

//What is the Solutions for debugging 