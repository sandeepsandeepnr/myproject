var myString;
var myNumber;
var myBoolean;
myString = "1";
myNumber = 1;
myBoolean = true;
myString = myNumber;
myBoolean = myString;
myNumber = myBoolean;
