var inferredString = "this is a string";
var inferredNumber = 1;
inferredString = inferredNumber;
