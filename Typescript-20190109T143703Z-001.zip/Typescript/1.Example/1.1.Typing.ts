function doCalculation( 
    a : number, 
    b : number, 
    c : number) { 
    return ( a * b ) + c; 
  } 

  var result = doCalculation(3,2,1); 
  console.log("doCalculation():" + result); 
