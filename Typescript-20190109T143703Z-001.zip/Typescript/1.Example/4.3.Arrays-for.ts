var arrayOfStrings : string[] = ["first", "second", "third"]; 
 
for( var arrayItem of arrayOfStrings ) { 
    console.log(`arrayItem = ${arrayItem} `); 
  }   