function doCalculation(a, b, c) {
    return (a * b) + c;
}
var result = doCalculation("3", "2", "1");
console.log("doCalculation():" + result);
var color = "blue";
console.log(color);
