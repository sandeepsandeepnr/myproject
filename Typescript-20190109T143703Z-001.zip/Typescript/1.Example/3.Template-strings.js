var myVariable = "test";
console.log("myVariable=" + myVariable);
var myVariable = "test";
console.log("myVariable=" + myVariable);
