var myString : string; 
var myNumber : number; 
var myBoolean : boolean; 
myString = "1"; 
myNumber = 1; 
myBoolean = true; 


myString = myNumber; 
myBoolean = myString; 
myNumber = myBoolean; 

