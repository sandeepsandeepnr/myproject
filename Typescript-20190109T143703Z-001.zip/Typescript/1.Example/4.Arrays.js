var arrayOfNumbers = [1, 2, 3];
arrayOfNumbers = [3, 4, 5, 6, 7, 8, 9];
console.log("arrayOfNumbers: " + arrayOfNumbers);
//arrayOfNumbers = ["1", "2", "3"]; 
