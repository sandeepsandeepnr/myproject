function greetUser( username ) {
 return `Hi, ${username}`
}

console.log('Greet a user string: ', greetUser('Sathish'))
console.log('Greet a boolean: ', greetUser(true))
console.log('Greet a number: ', greetUser(1))

//loosely typed are inconsistent(major problem)
//their value types can change
//flexibility - the freedom to change types anytime and anywhere