// Declare a variable and assign a value
var x = "Hello";
// Re-assign the value
x = 1;
// Log value
console.log(x); // 1