var complexType = { name: "myName", id: 1 };
complexType = { id: 2, name: "anotherName" };
