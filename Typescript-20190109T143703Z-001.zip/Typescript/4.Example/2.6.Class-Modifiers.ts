//public
class ClassWithPublicProperty { 
    public id: number; 
} 

let publicAccess = new ClassWithPublicProperty(); 
publicAccess.id = 10; 
console.log(publicAccess)
  
  
  //private

  class ClassWithPrivateProperty { 
    private id: number; 
    constructor(_id : number) { 
      this.id = _id; 
     
    } 
  } 

  let privateAccess = new ClassWithPrivateProperty(10); 
  privateAccess.id = 20; 