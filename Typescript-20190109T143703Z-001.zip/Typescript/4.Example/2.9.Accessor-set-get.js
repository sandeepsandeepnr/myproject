var ClassWithAccessors = /** @class */ (function () {
    function ClassWithAccessors() {
    }
    Object.defineProperty(ClassWithAccessors.prototype, "id", {
        get: function () {
            console.log("inside get id()");
            return this._id;
        },
        set: function (value) {
            console.log("inside set id()");
            this._id = value;
        },
        enumerable: true,
        configurable: true
    });
    return ClassWithAccessors;
}());
var classWithAccessorsObj = new ClassWithAccessors();
classWithAccessorsObj.id = 2;
console.log("id property is set to " + classWithAccessorsObj.id);
//tsc --target es5 script.ts
