var SimpleClass = /** @class */ (function () {
    function SimpleClass() {
    }
    SimpleClass.prototype.print = function () {
        console.log("SimpleClass.print() called");
    };
    return SimpleClass;
}());
var mySimpleClass = new SimpleClass();
mySimpleClass.print();
