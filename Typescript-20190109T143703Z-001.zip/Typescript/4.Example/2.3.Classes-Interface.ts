class ClassA implements IPrint { 
    print() { console.log('ClassA.print()') }; 
  } 

  class ClassB implements IPrint { 
    print() { console.log(`ClassB.print()`)}; 
  } 

  interface IPrint { 
    print(); 
  } 

  function printClass( a : IPrint ) { 
    a.print(); 
  } 

let ClassAobj = new ClassA(); 
printClass(ClassAobj); 

let ClassBobj = new ClassB();
printClass(ClassBobj);