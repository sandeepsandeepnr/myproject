interface IComplexType { 
    id: number; 
    name: string; 
  } 

class ComplexType implements IComplexType { 
    id: number; 
    name: string; 
   constructor(idArg: number, nameArg: string); 
    constructor(idArg: string, nameArg: string); 
    constructor(idArg: any, nameArg: any)  { 
      this.id = idArg; 
      this.name = nameArg; 
    } 
    print(): string { 
      return "id:" + this.id + " name:" + this.name; 
    } 
    usingTheAnyKeyword(arg1: any): any { 
      this.id = arg1; 
    } 
    usingOptionalParameters(optionalArg1?: number) { 
      if (optionalArg1) { 
        this.id = optionalArg1; 
      } 
    } 
    usingDefaultParameters(defaultArg1: number = 0) { 
      this.id = defaultArg1; 
    } 
    usingRestSyntax(...argArray: number []) { 
      if (argArray.length > 0) { 
        this.id = argArray[0]; 
      } 
    } 
    usingFunctionCallbacks( callback: (id: number) => string  ) { 
      callback(this.id); 
    } 

  } 

  let obj1 = new ComplexType(1,"object one");
  
  obj1.usingTheAnyKeyword(4);
  
  //let obj2 = new ComplexType("object two",4);
  //let obj3 = new ComplexType(true,2);
  
 //obj1.print();
 console.log(obj1)
