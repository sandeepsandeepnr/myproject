interface IOptionalProp { 
      id: number; 
      name?: string; 
    } 

    let idOnly : IOptionalProp = {id :1};
    let idAndName : IOptionalProp = {id: 1 , name: "Sathish"}
    idAndName = idOnly; 
   // idOnly.name="kumar";
    console.log(idAndName)
