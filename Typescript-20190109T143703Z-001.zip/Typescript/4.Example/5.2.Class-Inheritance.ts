class BaseClass implements IBase { 
    id: number; 
  } 

  class DerivedFromBaseClass extends BaseClass 
    implements IDerivedFromBase { 
      name: string; 
  } 

  let obj1 = new DerivedFromBaseClass();
  obj1.id=45;
  obj1.name="Atos";
  console.log(obj1);