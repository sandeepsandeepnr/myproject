var idOnly = { id: 1 };
var idAndName = { id: 1, name: "Sathish" };
idAndName = idOnly;
// idOnly.name="kumar";
console.log(idAndName);
