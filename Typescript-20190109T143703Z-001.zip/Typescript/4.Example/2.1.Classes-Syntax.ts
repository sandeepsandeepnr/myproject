class SimpleClass { 
      print() : void { 
        console.log(`SimpleClass.print() called`); 
      } 
    } 
let mySimpleClass = new SimpleClass();
mySimpleClass.print();