//public
var ClassWithPublicProperty = /** @class */ (function () {
    function ClassWithPublicProperty() {
    }
    return ClassWithPublicProperty;
}());
var publicAccess = new ClassWithPublicProperty();
publicAccess.id = 10;
console.log(publicAccess);
//private
var ClassWithPrivateProperty = /** @class */ (function () {
    function ClassWithPrivateProperty(_id) {
        this.id = _id;
        privateAccess.id = 20;
    }
    return ClassWithPrivateProperty;
}());
var privateAccess = new ClassWithPrivateProperty(10);
