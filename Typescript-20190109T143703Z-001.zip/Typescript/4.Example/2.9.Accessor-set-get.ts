class ClassWithAccessors { 
    private _id : number; 
    get id() { 
      console.log(`inside get id()`); 
      return this._id; 
    } 
    set id(value:number) { 
      console.log(`inside set id()`); 
      this._id = value; 
    } 
  } 

  let classWithAccessorsObj = new ClassWithAccessors(); 
   // classWithAccessorsObj.id = 2; 
    console.log(`id property is set to ${classWithAccessorsObj.id}`); 
  //tsc --target es5 script.ts