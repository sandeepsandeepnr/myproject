interface IFirstInterface { 
    id : number 
  } 
  interface ISecondInterface { 
    name: string; 
  } 
  class MultipleInterfaces implements 
    IFirstInterface, ISecondInterface { 
      id: number; 
      name: string; 
  } 

  let obj = new MultipleInterfaces();
  obj.name="myAtos Typescript"
  console.log(obj)