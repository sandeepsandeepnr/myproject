class Employee { 
      public id: number; 
      public name: string; 
      printDetails() { 
        console.log(`id: ${this.id}`  
         + `, name ${this.name}`); 
      } 
    } 
 
    class Manager { 
      public id: number; 
      public name: string; 
      public Employees: Employee[]; 
      printDetails() { 
        console.log(`id: ${this.id} ` 
        + `, name ${this.name}, ` 
        + ` employeeCount ${this.Employees.length}`); 
      } 
    } 