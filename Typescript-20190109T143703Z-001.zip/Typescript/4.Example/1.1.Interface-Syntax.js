var complexType;
complexType = { id: 1, name: "test" };
console.log(complexType);
