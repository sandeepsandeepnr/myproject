var ClassWithReadOnly = /** @class */ (function () {
    function ClassWithReadOnly(_name) {
        this.name = _name;
    }
    ClassWithReadOnly.prototype.setReadOnly = function (_name) {
        // generates a compile error 
        this.name = _name;
    };
    return ClassWithReadOnly;
}());
