  interface IComplexType { 
      id: number; 
      name: string; 
    } 
    let complexType : IComplexType; 
    complexType = { id: 1, name : "test" }; 
    console.log(complexType)