var classWithAutomaticProperties = /** @class */ (function () {
    function classWithAutomaticProperties(id, name) {
        this.id = id;
        this.name = name;
        name = "kumar";
        console.log(name);
    }
    return classWithAutomaticProperties;
}());
var myAutoClass = new classWithAutomaticProperties(1, "className");
console.log("myAutoClass id: " + myAutoClass.id);
//console.log(`myAutoClass.name: ${myAutoClass.name}`); 
