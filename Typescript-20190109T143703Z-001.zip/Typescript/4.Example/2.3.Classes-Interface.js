var ClassA = /** @class */ (function () {
    function ClassA() {
    }
    ClassA.prototype.print = function () { console.log('ClassA.print()'); };
    ;
    return ClassA;
}());
var ClassB = /** @class */ (function () {
    function ClassB() {
    }
    ClassB.prototype.print = function () { console.log("ClassB.print()"); };
    ;
    return ClassB;
}());
function printClass(a) {
    a.print();
}
var ClassAobj = new ClassA();
printClass(ClassAobj);
var ClassBobj = new ClassB();
printClass(ClassBobj);
