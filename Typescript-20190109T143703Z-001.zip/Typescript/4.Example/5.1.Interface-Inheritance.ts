c
    interface IDerivedFromBase extends IBase { 
      name: string; 
    } 
 
    class InterfaceInheritanceClass implements
      IDerivedFromBase { 
        id: number; 
        name: string; 
    } 
 

    let obj1 = new InterfaceInheritanceClass();
    obj1.id=23;
    obj1.name="Sathish";
    console.log(obj1)