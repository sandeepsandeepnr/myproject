class BaseClassWithFunction { 
    public id : number; 
    getProperties() : string { 
      return `id: ${this.id}`; 
    } 
  } 

  class DerivedClassWithFunction extends
    BaseClassWithFunction { 
      public name: string; 
      getProperties() : string { 
        return `${super.getProperties()}` 
        + ` , name: ${this.name}`; 
      } 
  } 

  let obj = new DerivedClassWithFunction(); 
  obj.id = 1; 
  obj.name = "derivedName"; 
  console.log(obj.getProperties()); 