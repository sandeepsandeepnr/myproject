var MultipleInterfaces = /** @class */ (function () {
    function MultipleInterfaces() {
    }
    return MultipleInterfaces;
}());
var obj = new MultipleInterfaces();
obj.name = "myAtos Typescript";
console.log(obj);
