class StaticClass { 
      static printTwo() { 
        console.log(`2`); 
      } 
    } 
 
    StaticClass.printTwo(); 