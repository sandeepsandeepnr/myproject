class classWithAutomaticProperties { 
    constructor(public id: number, private name: string){ 
    } 
  } 

  let myAutoClass = new classWithAutomaticProperties(
    1, "className"); 
  console.log(`myAutoClass id: ${myAutoClass.id}`); 
  console.log(`myAutoClass.name: ${myAutoClass.name}`); 