var InterfaceInheritanceClass = /** @class */ (function () {
    function InterfaceInheritanceClass() {
    }
    return InterfaceInheritanceClass;
}());
var obj1 = new InterfaceInheritanceClass();
obj1.id = 23;
obj1.name = "Sathish";
console.log(obj1);
