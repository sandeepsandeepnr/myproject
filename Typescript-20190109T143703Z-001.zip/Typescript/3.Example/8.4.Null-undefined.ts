/* function testUndef(test) { 
    console.log('test parameter :' + test); 
  } 

  testUndef(); 
  testUndef(null);  */

/*   function testUndef(test : null | number) { 
    console.log('test parameter :' + test); 
  } 
testUndef();  */

let x : number | undefined; 
 
    x = 1; 
    x = undefined; 
    x = null; 