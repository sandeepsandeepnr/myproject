function addNumbers(a, b) {
    return a + b;
}
var addResult = addNumbers(2, 3);
console.log("addNumbers returned : " + addResult);
