/* function printFullName(firstName:string,lastName:string):string{
    return firstName + " " + lastName;
  }
 let result = printFullName("sathish", "kumar");
  console.log(`${result}`) */
var result = function (firstName, lastName) { return firstName + " " + lastName; };
//equals symbol(=) followed by the greater than symbol(>)
