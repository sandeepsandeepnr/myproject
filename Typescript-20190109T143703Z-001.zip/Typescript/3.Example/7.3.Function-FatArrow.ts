function doSomethingWithACallback( 
  initialText:string,  
  callback : (initialText: string) => void 
) 

{ 
  console.log(`inside doSomethingWithCallback ${initialText}`); 
  callback(initialText); 
} 