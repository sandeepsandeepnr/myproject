var concatStrings = function(a,b,c) { 
      return a + b + c; 
    } 
    var concatAbc = concatStrings("a", "b", "c"); 
    console.log("concatAbc :" + concatAbc); 
 
    var concatAb = concatStrings("a", "b"); 
    console.log("concatAb :" + concatAb);