/* TypeScript allows us to express a type as the combination 
of two or more other types. 
This technique is known as union types, and uses the pipe symbol (|). */

var unionType : string | number;  //it can hold either a string or a number
 
unionType = 1; 
console.log(`unionType : ${unionType}`); 

unionType = "test"; 
console.log(`unionType : ${unionType}`); 
