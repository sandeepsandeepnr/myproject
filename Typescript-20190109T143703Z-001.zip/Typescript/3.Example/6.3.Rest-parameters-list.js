function testArguments(arg1, arg2) {
    var argArray = [];
    for (var _i = 2; _i < arguments.length; _i++) {
        argArray[_i - 2] = arguments[_i];
    }
    if (argArray.length > 0) {
        for (var i = 0; i < argArray.length; i++) {
            console.log("argArray[" + i + "] = " + argArray[i]);
            // use JavaScript arguments variable 
            console.log("arguments[" + i + "] = " + arguments[i]);
        }
    }
}
testArguments("sathish", 12);
testArguments("Hello", 2, 3);
