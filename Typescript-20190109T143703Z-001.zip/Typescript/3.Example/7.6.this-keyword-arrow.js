// lexical scope of the this keyword is based on the time when a function is executed
/* function Book(title) {
    this.title = title;
    this.printTitle = function () {
    this.title = this.title + " by Sathish";
    console.log(this.title);
    }
   }
   var typeScript = new Book("TypeScript Examples");
   setTimeout(typeScript.printTitle, 1000);
   setTimeout(function() { typeScript.printTitle(); },2000) */
//Typescript Arrow with this keyword
function Book(title) {
    var _this = this;
    this.title = title;
    this.printTitle = function () { return console.log(_this.title + " by Sathish"); };
}
var typeScript = new Book("TypeScript Exmaples");
setTimeout(typeScript.printTitle, 1000);
setTimeout(function () { typeScript.printTitle(); }, 2000);
