//TypeScript introduces a specific syntax, called function overloads.
function add(a, b) {
    return a + b;
}
console.log("add(1,1)= " + add(1, 1));
console.log("add(\"1\",\"1\")= " + add("1", "1"));
