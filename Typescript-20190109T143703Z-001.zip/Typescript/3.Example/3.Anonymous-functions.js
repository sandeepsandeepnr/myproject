var addVar = function (a, b) {
    return a + b;
};
var addVarResult = addVar(2, 3);
console.log("addVarResult:" + addVarResult);
//don't specify a function name
var addFunction = function (a, b) {
    return a + b;
};
var addFunctionResult = addFunction(2, 3);
console.log("addFunctionResult : " + addFunctionResult);
