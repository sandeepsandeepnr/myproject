function doSomethingWithACallback( initialText, callback ) { 
  console.log('inside doSomethingWithCallback ' + initialText); 
  if (typeof callback === "function") { 
    callback(initialText); 
  } else { 
      console.log(initialText + ' is not a function !!') 
    } 
} 
doSomethingWithACallback('myText', 'anotherText');

   /*  first check whether the callback parameter 
    was in fact a function before invoking it, */
/* 
    developers need to code around the invalid use of callback functions, and secondly, 
    developers need to document and understand which parameters are, in fact, callbacks. */