let firstObj = { id: 1, name : "firstObj"}; 
 
    //ES7 syntax to copy all of the properties of firstObj
  /*   let secondObj = { ...firstObj }; 
    console.log(`secondObj.id : ${secondObj.id}`); 
    console.log(`secondObj.name : ${secondObj.name}`); */ 

   // Combaine Multiple Objects together

     let nameObj = { name : "nameObj"}; 
     let idObj = { id : 2}; 
 
     let obj3 = { ...nameObj, ...idObj }; 
     console.log(`obj3.id : ${obj3.id}`); 
     console.log(`obj3.name : ${obj3.name}`); 