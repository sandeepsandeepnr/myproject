type StringOrNumber = string | number; 
 
    function addWithAlias( 
      arg1 : StringOrNumber,  //defined a type alias, named StringOrNumber
      arg2 : StringOrNumber 
    ) { 
        return arg1.toString() + arg2.toString(); 
    }   


/*     type CallbackWithString = (string) => void; 
 
    function usingCallbackWithString(
      callback: CallbackWithString) { 
        callback("this is a string"); 
      }  */