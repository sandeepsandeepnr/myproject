var callbackFunction = function(text) { 
    console.log('inside callbackFunction ' + text); 
  } 

  function doSomethingWithACallback( initialText, callback ) { 
    console.log('inside doSomethingWithCallback ' + initialText); 
    callback(initialText); 
  } 

  doSomethingWithACallback('myText', callbackFunction);

  // A callback function is a function that is passed into another function, 
  //and is then generally invoked inside the function.

  // case 1: pass a value into a function
  // case 2: pass a function into a function