function add(x,y) { 
    return x + y; 
  } 

  console.log('add(1,1)=' + add(1,1));         //two numbers
  console.log('add("1","1")=' + add("1","1")); //two string