function addNumbers(a: number, b: number) : number { 
    return a + b;
  } 
  var addResult = addNumbers(2,3); 
  console.log(`addNumbers returned : ${addResult}`);