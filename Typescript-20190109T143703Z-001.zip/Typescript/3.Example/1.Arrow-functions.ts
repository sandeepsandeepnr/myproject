/* function printFullName(firstName:string,lastName:string):string{
    return firstName + " " + lastName;
  }
 let result = printFullName("sathish", "kumar");
  console.log(`${result}`) */

  //equals symbol(=) followed by the greater than symbol(>)

  //Empty parameters:
  () => console.log("Hello World!!");
  
  //Single parameter
  id => console.log(id);

  //Multiple parameters
  let result = (firstName: string, lastName: string) => firstName + " " + lastName;

  //Multiline function body
  (firstName, lastName, age): number => {
    console.log(firstName + ' ' + lastName); 
    return age + 1;
    // do more stuff here
    };

