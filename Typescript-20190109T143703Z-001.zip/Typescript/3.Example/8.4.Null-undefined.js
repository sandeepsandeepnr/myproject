/* function testUndef(test) {
    console.log('test parameter :' + test);
  }

  testUndef();
  testUndef(null);  */
/*   function testUndef(test : null | number) {
    console.log('test parameter :' + test);
  }
testUndef();  */
var x;
x = 1;
x = undefined;
x = null;
