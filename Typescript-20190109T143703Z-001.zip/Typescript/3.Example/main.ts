function dowork(){
for(let i=0; i<5; i++){
    console.log(i);
}
//console.log('Finally:' +i);
}
dowork();

//let count = 5;
//count = 'a';
let b;
let a:string;
//a =1;
a="hello";