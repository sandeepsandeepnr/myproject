function log(message){
    console.log(message);
}

let message = 'Hello World';
log(message);