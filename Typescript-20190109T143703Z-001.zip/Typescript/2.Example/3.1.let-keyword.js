var lValue = 2;
console.log("lValue = " + lValue);
if (lValue == 2) {
    var lValue_1 = 2001;
    console.log("block scoped lValue : " + lValue_1 + " ");
}
console.log("lValue = " + lValue);
