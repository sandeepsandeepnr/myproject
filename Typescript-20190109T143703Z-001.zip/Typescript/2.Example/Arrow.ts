var data = ['Angular', 'Typescript', 'Ionic'];
data.forEach(function(line) { console.log(line); });

var data: string[] = ['Angular', 'Typescript', 'Ionic'];
data.forEach( (line) => console.log(line) );