console.log(`anyValue = ${anyValue}`); 
var anyValue = 2; 
console.log(`anyValue = ${anyValue}`); 