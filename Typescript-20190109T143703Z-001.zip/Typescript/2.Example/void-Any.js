function returnNothing(num) {
    console.log("Moo" + num);
}
returnNothing(45);
// Stores a string
var firstname = "John Doe";
// Stores a number
var age = 24;
// Stores a boolean
var employed = true;
// ...even data structures
var person = ['John Doe', 24, true];
