var data = ['Angular', 'Typescript', 'Ionic'];
data.forEach(function (line) { console.log(line); });
var data = ['Angular', 'Typescript', 'Ionic'];
data.forEach(function (line) { return console.log(line); });
