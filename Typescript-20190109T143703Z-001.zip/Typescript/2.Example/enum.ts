const enum DoorState { 
    Open, 
    Closed, 
    Ajar 
  } 

  //var Doorstatus = DoorState.Closed; 
 var Doorstatus = DoorState["Closed"];
 // console.log(`openDoor is: ${Doorstatus}`);
  //console.log(`${DoorState[0]}`);  



 /*  var DoorState; 
    (function (DoorState) { 
      DoorState[DoorState["Open"] = 0] = "Open"; 
      DoorState[DoorState["Closed"] = 1] = "Closed"; 
      DoorState[DoorState["Ajar"] = 2] = "Ajar"; 
    })(DoorState || (DoorState = {})); 
  */
