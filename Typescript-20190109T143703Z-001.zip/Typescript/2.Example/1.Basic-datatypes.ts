let text1: string = "Hi How are you";
let text2: string = 'Now you know';
console.log(text1)
console.log(text2)
//ES6 template literal
const user:string='Sathish';
let text3: string = `Hi I am ES6 String Literal and my developer name ${user}`;
console.log(text3)
//JavaScript and TypeScript
//the literals are represented with both double quotes ("") and single quotes (''):



//Numabers
let whole: number = 6;
let decimal: number = 2.5;
let hex: number = 0xf00d; 
let binary: number = 0b1010; 
let octal: number = 0o744;
//console.log(whole)

//Boolean
let isHappy: boolean = true;
let done: boolean = false;

//Arrays

let textArray: string[];
textArray = ["java", "kotlin", "typescript", "the rest..."]
//console.log(textArray)
let numberArray: Array<number> = [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]

