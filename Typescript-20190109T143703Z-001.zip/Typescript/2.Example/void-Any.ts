//void is available only in TypeScript
function returnNothing(): void {
    console.log("Moo");
    //return "Hello World"
  }


//Any is available only in TypeScript

  // Stores a string
let firstname: any = "John Doe" 

// Stores a number
let age: any = 24

// Stores a boolean
let employed: any = true

// ...even data structures
let person: any[] =['John Doe', 24, true] 